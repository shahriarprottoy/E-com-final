package com.example.zayans_eshop.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.zayans_eshop.MainActivity;
import com.example.zayans_eshop.R;
import com.example.zayans_eshop.SettingsActivity;
import com.example.zayans_eshop.data.UserAccount;

import java.util.Objects;

public class signed__in__account__fragment extends Fragment {

    private TextView userName;
    private TextView userPhone;
    private TextView userEmail;
    private TextView userLocation;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.signed_in_account_fragment, container, false);

        userName = root.findViewById(R.id.un);
        userPhone = root.findViewById(R.id.phoneNumber);
        userEmail = root.findViewById(R.id.emailAddress);
        userLocation = root.findViewById(R.id.locationText);
        Button settingsButton = root.findViewById(R.id.edit_account_button);

        UserAccount userAccount = MainActivity.userAccount;

        userName.setText(userAccount.getUserName());
        userPhone.setText(userAccount.getUserPhone());
        userEmail.setText(userAccount.getUserEmail());
        userLocation.setText(userAccount.getUserLocation());

        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), SettingsActivity.class);

                startActivity(intent);
            }
        });

        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!MainActivity.loginFlag) {
            Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new account__fragment()).commit();
        } else {
            UserAccount userAccount = MainActivity.userAccount;

            userName.setText(userAccount.getUserName());
            userPhone.setText(userAccount.getUserPhone());
            userEmail.setText(userAccount.getUserEmail());
            userLocation.setText(userAccount.getUserLocation());
        }
    }
}
